const c=document.getElementById("myCanvas");
const ctx=c.getContext("2d");
let x=20;let v=2;

function anim(){
  ctx.clearRect(0,0,c.width,c.height);
  ctx.beginPath();
  ctx.arc(x,150,40,0,Math.PI*2);
  ctx.fillStyle="orange";
  ctx.fill();
  x+=v;
  if(x>560||x<40)v=-v;
  requestAnimationFrame(anim);
}
anim();
